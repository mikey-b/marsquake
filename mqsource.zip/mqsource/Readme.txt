Marsquake v1.14 Source code
(C) Paul Taylor (paul@cyplexia.demon.co.uk)

A bomberman style game written for Acorn computers or compatible, running RISC OS. The code is a mixture of C and ARM assembly language, split into the following subdirectories :

	C - c files
	H - header files
	S - assembly language files

Note that the filenames do not have extensions, just as they appear within RISC OS's filer. They are, in fact, just plain text. 

--
18th June 2000